import { createStore } from 'vuex'
export default createStore({
    // vux 에 데이터 변수 설정
    state: {    
       // toastBox 관련
       showToast : false,
       toastMessage : '',
       toastAlertType : '',
       toastTimeout : null
    }
});