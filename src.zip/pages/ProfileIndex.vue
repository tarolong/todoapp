<template>
    <h1>Profile page</h1>
</template>
<script>
export default {}
</script>
<style>
</style>