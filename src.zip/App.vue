<template>
  <!-- 상단메뉴 -->
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
      <router-link class="nav-link" :to="{name: 'Home'}">Home</router-link>
      <router-link class="nav-link" :to="{name: 'Todos'}">Todos</router-link>
      <router-link class="nav-link" :to="{name: 'About'}">About</router-link>
      <router-link class="nav-link" :to="{name:'Profile'}">Profile</router-link>      
    </div>
  </nav>


  <!-- 라우터 화면 보여주기 -->
  <div class="container">
    <router-view />    
    <!-- 안내창 -->
    <ToastBox v-if="showToast" :message="toastMessage" :type="toastAlertType" />
  </div>

</template>

<script>

  import ToastBox from '@/components/ToastBox.vue';
  import { useToast } from '@/composables/toast.js';
  import { useStore } from 'vuex'

  export default {
    components: {
      ToastBox
    },
    setup() {    

      const store = useStore();

      console.log(store);
      console.log(store.state) ;
      console.log(store.state.showToast);
      
      
      // ToastBox 관련
      const {
        showToast,
        toastMessage,
        triggerToast,
        toastAlertType
      } = useToast();

      return {
        showToast,
        toastMessage,
        triggerToast,
        toastAlertType
      }
    }
  }
</script>

<style>

</style>